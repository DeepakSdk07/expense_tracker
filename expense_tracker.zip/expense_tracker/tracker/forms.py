from django import forms
from .models import Expense,Budget

class ExpenseForm(forms.ModelForm):
    class Meta:
        model=Expense
        fields="__all__"

class BudgetForm(forms.ModelForm):
    class Meta:
        model=Budget
        fields=['monthly_budget']