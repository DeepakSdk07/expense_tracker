from django.shortcuts import render,redirect
from .models import Expense,Budget
from .forms import ExpenseForm,BudgetForm
from django.db.models import Sum

def home(request):
    expenses=Expense.objects.all()
    total_expenses=expenses.aggregate(Sum("amount"))["amount__sum"] or 0
    budget=Budget.objects.all()
    remaining=budget.monthly_budget-total_expenses if budget else 0

    return render(request,"tracker/home.html",{
        'expenses':expenses,
        'total':total_expenses,
        'budget':budget,
        'remaining':remaining,
    })

def add_expenses(request):
    if request.method=="POST":
        form=ExpenseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("home")
    else:
        form=ExpenseForm
    
    return render(request,"tracker/add_expense.html",{'form':form})

def set_budget(request):
    if request.method=="POST":
        form=BudgetForm(request.POST)
        if form.is_valid():
            Budget.objects.all().delete()
            form.save()
            return redirect("home")

    else:
        form=BudgetForm()
    
    return render(request,"tracker/budget.html",{'form':form})