from django.db import models

class Budget(models.Model):
    monthly_budget=models.FloatField()
    created_at=models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Budget: {self.monthly_budget}'

class Expense(models.Model):
    title=models.CharField(max_length=100)
    amount=models.FloatField()
    category=models.CharField(max_length=100)
    date=models.DateTimeField(auto_now_add=True)

    def __str__():
        return self.title
