from django.urls import path 
from .views import home,add_expenses,set_budget

urlpatterns=[
    path("",home,name='home'),
    path("add-expense/",add_expenses,name='add_expense'),
    path("set-budget/",set_budget,name='set_budget'),
]